const apiId = 'd5moervel7'
export const apiEndpoint = `https://${apiId}.execute-api.ap-southeast-1.amazonaws.com/dev`

export const authConfig = {
  domain: 'dev-5jigfg6s.auth0.com',
  clientId: 'QKK3A4DTCtpT6ADLfwv7y621xXk3hYwX',
  callbackUrl: 'http://localhost:3000/callback'
}
