const apiId = 'zpecfihm29';
export const apiEndpoint = `https://${apiId}.execute-api.us-east-1.amazonaws.com/dev`

export const authConfig = {
  domain: 'manish-udacity.auth0.com',
  clientId: 'qsvvfT6r9zKcDiY4EpkoKeXid0m0ZzTj',
  callbackUrl: 'http://localhost:3000/callback'
};
